#!/bin/sh

echo sss >> ~/inner_script